'use strict'; 
var os = require("os"); 
global.hostname = os.hostname(); 
global.uuid = 
{"hostname":global.hostname,
      "uuid":[],
      "init_time":new Date(),
      "curr_time":new Date()
};
var function_handler = function(event, context, callback) {
	var r = 0.0;
	r = main(context, event);
	var result = { "elapsed_time": r,
		"hostname": global.hostname,
		"params": event
		}
	console.log(JSON.stringify(result));

	callback(null, r);
}

var multiple_row_and_column = function(row, column){
	// assume same length of row and column
	var result = 0;
	for(var i = 0; i < row.length; i++)
	{
	  result += row[i] * column[i];
	}
	return result;
}

var create_random_matrix = function(size, seed, value_min, value_max) {
	var matrix = [];
	for (var i = 0; i < size; i++) {
	  var row = [];
	  for (var j = 0; j < size; j++){
	      var val = parseFloat(Math.random(seed) * (value_max - value_min));
	      row.push(val);
	  }
	  matrix.push(row);
	}
	return matrix;
}

var get_row_from_matrix = function(matrix, i){
	return matrix[i];
}

var get_column_from_matrix = function(matrix, j){
	var column = [];
	for(var i = 0; i < matrix.length; i++){
	  column.push(matrix[i][j]);
	}
	return column;
}

var multiple_matrix = function(matrixA, matrixB) {
	var result = [];
	for (var i = 0; i < matrixA.length; i++) {
	  var result_row = [];
	  for (var j = 0; j < matrixA[0].length; j++) {
	      var row = get_row_from_matrix(matrixA, i);
	      var column = get_column_from_matrix(matrixB, j);
	      result_row.push(multiple_row_and_column(row, column));
	  }
	  result.push(result_row);
	}
	return result;
}

var print_matrix = function(matrix){
	for (var i = 0; i < matrix.length; i++) {
	  var row = '';
	  for (var j = 0; j < matrix[0].length; j++) {
	      row += (' ' + matrix[i][j]);
	  }
	  console.log(row);
	}
}

var main = function (context, req) {
	var seed = 123.0;
	var value_min = 0.0;
	var value_max = 101.0;
	var size = parseInt(req.mat_n);

	var matrix = create_random_matrix(size, seed, value_min, value_max);
	seed = 2 * seed;
	var matrix2 = create_random_matrix(size, seed, value_min, value_max);
	var startTime = new Date();
	multiple_matrix(matrix, matrix2);
	var endTime = new Date();
	var timeDiff = endTime - startTime;
	timeDiff /= 1000;

	global.uuid['curr_time'] = new Date();
	global.uuid['uuid'].push(req.cid)
	console.log(JSON.stringify(global.uuid))
	return timeDiff;
}
